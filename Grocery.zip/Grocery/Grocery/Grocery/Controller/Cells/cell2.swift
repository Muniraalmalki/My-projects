//
//  cell2.swift
//  Grocery
//
//  Created by munira almallki on 09/04/1443 AH.
//


import UIKit

class cell2: UITableViewCell {

    
    @IBOutlet weak var emailLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    

}
