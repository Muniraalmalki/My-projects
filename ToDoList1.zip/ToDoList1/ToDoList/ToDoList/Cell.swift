//
//  Cell.swift
//  ToDoList
//
//  Created by munira almallki on 12/03/1443 AH.
//

import UIKit

class Cell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var notesLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
}

