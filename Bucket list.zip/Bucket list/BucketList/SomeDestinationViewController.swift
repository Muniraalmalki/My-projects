//
//  SomeDestinationViewController.swift
//  BucketList
//
//  Created by munira almallki on 05/03/1443 AH.
//

import UIKit

class SomeDestinationViewController: UITableViewController {
    var someStringSetDuringSegue: String?  // Note: These aren't the best names!
        var someIndexPathSetDuringSegue: Int?
    override func viewDidLoad() {
        super.viewDidLoad()


}
}
