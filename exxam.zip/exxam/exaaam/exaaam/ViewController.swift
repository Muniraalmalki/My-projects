//
//  ViewController.swift
//  exaaam
//
//  Created by munira almallki on 26/02/1443 AH.
//

import UIKit

class ViewController: UIViewController {
    let question  = ["Whatisthetermforthephysicalcomponentofastoragedevice?","What is the surface of a disk drive platter or tape coated with?" , "Unlike tape, the read head can access any data on a disk drive, so it is said to be what type of device?"]
    let answer = [["Optical storage" ,"Magnetic storage", "Solid-state storage","Storage device"],["Aluminum","Iron oxide","Plastic","Silicon"],["Sequential access" , " Solid-state access","Random access."," Direct access."]]
    var currentQuestion = 0
    var rightAnswerPlacement : Int32 = 0
    @IBOutlet weak var questions: UILabel!
    
    @IBAction func exam(_ sender: UIButton) {
        
        if(sender.tag == Int(rightAnswerPlacement)){
            print("right")
        }else{
            print("error")
        }
        if ( currentQuestion != question.count){
            listQuestion()
        }
       
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func listQuestion(){
        questions.text = question[currentQuestion]
        rightAnswerPlacement =  Int32(arc4random_uniform(4)+1)
        
        var button: UIButton = UIButton()
        var x = 1
        for i in 1...4
        {
            button = view.viewWithTag(i) as! UIButton
            if (i == Int(rightAnswerPlacement))
            {
                button.setTitle((answer[currentQuestion][0]), for: .normal)
            }
            else {
                button.setTitle(answer[currentQuestion][x], for: .normal)
                x = 2
            }
        }
        currentQuestion += 1
  }


}




