//
//  profilleUIApp.swift
//  profilleUI
//
//  Created by munira almallki on 04/04/1443 AH.
//

import SwiftUI

@main
struct profilleUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
