//
//  profileCardApp.swift
//  profileCard
//
//  Created by munira almallki on 03/04/1443 AH.
//

import SwiftUI

@main
struct profileCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
