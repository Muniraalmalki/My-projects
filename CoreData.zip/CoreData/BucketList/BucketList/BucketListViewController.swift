//
//  BucketListViewController.swift
//  BucketList
//
//  Created by munira almallki on 06/03/1443 AH.
//

import UIKit
import CoreData
class BucketListViewController: UITableViewController , AddItemTableViewControllerDelegate {
var items = [BucketListItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        fetchItem()
        // Do any additional setup after loading the view.
    }
    func getUpdatedContext()->NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }

    func addItem (text: String){
       let context = getUpdatedContext()
        let item = BucketListItem.init(context: context)
        item.text = text
        items.append(item)
        do{
            try context.save()
        }catch{
            print(error.localizedDescription)
        }
    }
    func fetchItem(){
        let context = getUpdatedContext()
        let itemRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"BucketListItem")
        do {
            let result = try context.fetch(itemRequest)
            items = result as! [BucketListItem]
        } catch {
                    print("Read Error:\(error)")
                }
    }
    func updateItem(text:String , path: Int){
        let context = getUpdatedContext()
        items[path].text = text
        do{
            try context.save()
        }catch{
            print(error.localizedDescription)
        }
    }
    func delateItem(path: Int){
        let context = getUpdatedContext()
        
        context.delete(items[path])
        items.remove(at: path)
        
        do{
            try context.save()
        }catch{
            print(error.localizedDescription)
        }
    }


    @IBAction func AddButton(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row].text
        return cell
    }
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
           performSegue(withIdentifier: "oneSegue", sender: indexPath)
    }
    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        delateItem(path: indexPath.row)
        
        tableView.reloadData()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let sender = sender as? UIBarButtonItem {
                let navigationController = segue.destination as! UINavigationController
                let controller = navigationController.topViewController as! AddItemTableViewController
                controller.delegate = self
            }
        else if let sender = sender as? NSIndexPath{
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! AddItemTableViewController
            controller.delegate = self
            
            let item = items[sender.row]
            controller.item = item.text
            controller.indexPath = sender
        }
       
        }
    
   
    
    
    
    
    func saveButtonPressed(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?) {
        if let ip = indexPath{
            updateItem(text:text,path:ip.row)
            
         }else {
             addItem(text: text)
         }
       
         tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    
    
    func cancelButtonPressed(by controller: AddItemTableViewController) {
        dismiss(animated: true, completion: nil)
    }
    
}

