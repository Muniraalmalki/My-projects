//
//  SrcondViewController.swift
//  MadLibs
//
//  Created by munira almallki on 03/03/1443 AH.
//

import UIKit

class SrcondViewController: UIViewController {
    var adj
    @IBOutlet weak var descrpitionLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
       // if let des = data{
          //  descrpitionLabel.text = "We are having perfecty \(des.adj) time now . Later we will \(des.v1) and \(des.v2) in the \(des.noum)"
        }
        // Do any additional setup after loading the view.
    }
    

}
