//
//  SecondViewController.swift
//  MadLibs
//
//  Created by munira almallki on 03/03/1443 AH.
//

import UIKit

class SecondViewController: UIViewController {
   
 
    


}
