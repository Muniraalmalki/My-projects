//
//  ViewController.swift
//  BucketList
//
//  Created by munira almallki on 05/03/1443 AH.
//

import UIKit

class BucketListViewController: UITableViewController , AddItemTableViewControllerDelegate {
  

var name = ["Munira","Khaled","Banan","Arwa"]
    @IBAction func AddButton(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // Do any additional setup after loading the view.
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MissionCell", for: indexPath)
        cell.textLabel?.text = name[indexPath.row]
        return cell
    }
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
           performSegue(withIdentifier: "oneSegue", sender: indexPath)
    }
    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        name.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let sender = sender as? UIBarButtonItem {
                let navigationController = segue.destination as! UINavigationController
                let controller = navigationController.topViewController as! AddItemTableViewController
                controller.delegate = self
            }
        else if let sender = sender as? NSIndexPath{
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! AddItemTableViewController
            controller.delegate = self
            _ = sender
            let item = name[sender.row]
           controller.item = item
          controller.indexPath = sender
        }
       
        }
    
    
    func someViewControllerDelegate(_ controller: AddItemTableViewController, text: String, at indexPath: NSIndexPath?) {
        if let ip = indexPath{
             name[ip.row] = text
         }else {
             name.append(text)
         }
     
         tableView.reloadData()
    }
    
    
    func saveButtonPressed(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?) {
       if let ip = indexPath{
            name[ip.row] = text
        }else {
            name.append(text)
        }
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    
    
    func cancelButtonPressed(by controller: AddItemTableViewController) {
        dismiss(animated: true, completion: nil)
    }
    
}

