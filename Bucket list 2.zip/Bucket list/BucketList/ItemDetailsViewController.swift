//
//  ItemDetailsViewController.swift
//  BucketList
//
//  Created by munira almallki on 06/03/1443 AH.
//

import UIKit

class ItemDetailsViewController: UITableViewController {
    var someStringSetDuringSegue: String?  // Note: These aren't the best names!
        var someIndexPathSetDuringSegue: Int?
    override func viewDidLoad() {
        super.viewDidLoad()

        }

    
}
