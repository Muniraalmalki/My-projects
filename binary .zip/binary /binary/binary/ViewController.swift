//
//  ViewController.swift
//  binary
//
//  Created by munira almallki on 01/03/1443 AH.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var total = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        totalLabel.text = "Total:\(total)"
       
        tableView.dataSource = self
    }


}

extension ViewController : UITableViewDataSource , CustomCellDelegate {
    func add(amount: Int) {
        totalLabel.text = "Total:\(total)"
    }
    
    func sub(amount: Int) {
         totalLabel.text = "Total:\(total)"
    }
    

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return 16
        
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomTableViewCell
          let currentPower = pow(10, indexPath.row)
        cell.numberLabel.text = "\(currentPower)"
        func add(amount: Int) {
            if let amount = cell.numberLabel.text {
                if let finalamount = Int(amount){
                    self.total += finalamount
                    
                }
            
        }
                totalLabel.text = "Total:\(total)"
       }
        func sub(amount: Int) {
            if let amount = cell.numberLabel.text  {
                if let finalamount = Int(amount){
                               self.total -= finalamount
                }
        }
                totalLabel.text = "Total:\(total)"
       }
        return cell
    }
    
}

