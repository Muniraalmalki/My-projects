//
//  CustomTableViewCell.swift
//  binary
//
//  Created by munira almallki on 01/03/1443 AH.
//

import UIKit

protocol CustomCellDelegate : AnyObject{
    func add(amount: Int)
    func sub(amount: Int)
        
    
}
class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var numberLabel: UILabel!
    weak var delegate : CustomCellDelegate?
    var power : Int?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func plussButton(_ sender: UIButton) {
        if let power = power {
            delegate?.add(amount: power)
        }

        
    }
    @IBAction func minusButton(_ sender: UIButton) {
        if var num = power {
            num = -num
            delegate?.add(amount: num)
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

